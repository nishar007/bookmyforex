# BookMyForex Website

This is the official website for BookMyForex, a leading foreign exchange service provider.

## Features
- Currency Exchange Services
- Money Transfer
- Forex Cards
- Travel Insurance
- And more...

## Deployment
This website is deployed on Netlify.

## Technologies Used
- HTML5
- CSS3
- JavaScript
- Bootstrap 3.3.7 